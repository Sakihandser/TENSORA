// Copyright (c) 2010-2026, Lawrence Livermore National Security, LLC. Produced
// at the Lawrence Livermore National Laboratory. All Rights reserved. See files
// LICENSE and NOTICE for details. LLNL-CODE-806117.
//
// This file is part of the MFEM library. For more information and source code
// availability visit https://mfem.org.
//
// MFEM is free software; you can redistribute it and/or modify it under the
// terms of the BSD-3 license. We welcome feedback and contributions, see file
// CONTRIBUTING.md for details.

#ifdef _WIN32
#define _USE_MATH_DEFINES
#include <cmath>
#endif

#include "unit_tests.hpp"
#include "mfem.hpp"

#include "fem/integ/nonlininteg_vecconvection_pa.hpp" // IWYU pragma: keep
#include "fem/integ/nonlininteg_vecconvection_pa_diag.hpp" // IWYU pragma: keep
#include "fem/integ/nonlininteg_vecconvection_pa_grad.hpp" // IWYU pragma: keep
#include "fem/qinterp/grad.hpp" // IWYU pragma: keep

using namespace mfem;

namespace pa_kernels
{

template<int DIM>
void test_nl_convection_pa_grad(const char *filename, int p)
{
   CAPTURE(filename, DIM, p);

   Mesh mesh(filename);
   MFEM_VERIFY(mesh.Dimension() == DIM, "Mesh dimension mismatch");

   H1_FECollection fec(p, DIM);
   FiniteElementSpace fes(&mesh, &fec, DIM);

   GridFunction x(&fes), dx(&fes), y_fa(&fes), y_pa(&fes);
   x.Randomize(0x100001b3);
   dx.Randomize(0x9e3779b9);

   ConstantCoefficient const_coeff(M_2_SQRTPI);
   FunctionCoefficient funct_coeff([](const Vector &x)
   { return M_1_PI + x[0] * x[0]; });

   NonlinearForm nlf_fa(&fes);
   nlf_fa.AddDomainIntegrator(new VectorConvectionNLFIntegrator);
   nlf_fa.AddDomainIntegrator(new VectorConvectionNLFIntegrator(const_coeff));
   nlf_fa.AddDomainIntegrator(new VectorConvectionNLFIntegrator(funct_coeff));

   NonlinearForm nlf_pa(&fes);
   nlf_pa.SetAssemblyLevel(AssemblyLevel::PARTIAL);
   nlf_pa.AddDomainIntegrator(new VectorConvectionNLFIntegrator);
   nlf_pa.AddDomainIntegrator(new VectorConvectionNLFIntegrator(const_coeff));
   nlf_pa.AddDomainIntegrator(new VectorConvectionNLFIntegrator(funct_coeff));
   nlf_pa.Setup();

   SECTION("Action")
   {
      nlf_fa.Mult(x, y_fa), nlf_pa.Mult(x, y_pa);
      y_fa -= y_pa;
      REQUIRE(y_fa.Norml2() == MFEM_Approx(0.0));
   }

   SECTION("Gradient")
   {
      Operator &nlf_fa_grad = nlf_fa.GetGradient(x);
      Operator &nlf_pa_grad = nlf_pa.GetGradient(x);
      nlf_pa_grad.Mult(dx, y_pa);
      nlf_fa_grad.Mult(dx, y_fa);
      y_fa -= y_pa;
      REQUIRE(y_fa.Norml2() == MFEM_Approx(0.0));
   }

   SECTION("Diagonal")
   {
      Vector diag_fa(fes.GetVSize()), diag_pa(fes.GetVSize());
      dynamic_cast<SparseMatrix &>(nlf_fa.GetGradient(x)).GetDiag(diag_fa);
      nlf_pa.GetGradient(x).AssembleDiagonal(diag_pa);
      diag_fa -= diag_pa;
      REQUIRE(diag_fa.Norml2() == MFEM_Approx(0.0));
   }
}

TEST_CASE("NL Convection PA Gradient",
          "[PartialAssembly][NonlinearPA][GPU][NLConv]")
{
   const auto p_base = {1, 2}, p_extra = {3, 4};
   const auto p = MFEM_GENERATE_RANGES(p_base, p_extra);

   using Grad = QuadratureInterpolator::GradKernels;
   using NLVC = VectorConvectionNLFIntegrator;
   static const auto specializations =
      (Grad::Specialization<2, QVectorLayout::byNODES, false, 2, 2, 7>::Add(),
       Grad::Specialization<2, QVectorLayout::byNODES, false, 2, 3, 7>::Add(),
       Grad::Specialization<2, QVectorLayout::byNODES, false, 2, 4, 8>::Add(),
       Grad::Specialization<3, QVectorLayout::byNODES, false, 3, 2, 7>::Add(),
       Grad::Specialization<3, QVectorLayout::byNODES, false, 3, 3, 7>::Add(),
       Grad::Specialization<3, QVectorLayout::byNODES, false, 3, 3, 8>::Add(),
       Grad::Specialization<3, QVectorLayout::byNODES, false, 3, 4, 5>::Add(),
       Grad::Specialization<3, QVectorLayout::byNODES, false, 3, 4, 9>::Add(),
       // User specialization example for p=4 (D1D=5, Q1D=9) in 3D
       NLVC::AddSpecialization<3, 5, 9>(),
       true);
   MFEM_CONTRACT_VAR(specializations);

   SECTION("2D")
   {
      const auto meshs = { "../../data/inline-quad.mesh" };
      const auto extra = { "../../data/star-q2.mesh",
                           "../../data/star-q3.mesh",
                           "../../data/rt-2d-q3.mesh",
                           "../../data/periodic-square.mesh"
                         };
      test_nl_convection_pa_grad<2>(MFEM_GENERATE_RANGES(meshs, extra), p);
   }

   SECTION("3D")
   {
      const auto meshs = { "../../data/inline-hex.mesh" };
      const auto extra = { "../../data/fichera.mesh",
                           "../../data/beam-hex.mesh",
                           "../../data/toroid-hex.mesh",
                           "../../data/fichera-q2.mesh",
                           "../../data/fichera-q3.mesh",
                           "../../data/periodic-cube.mesh"
                         };
      test_nl_convection_pa_grad<3>(MFEM_GENERATE_RANGES(meshs, extra), p);
   }
}

} // namespace pa_kernels
