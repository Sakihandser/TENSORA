// Copyright (c) 2010-2026, Lawrence Livermore National Security, LLC. Produced
// at the Lawrence Livermore National Laboratory. All Rights reserved. See files
// LICENSE and NOTICE for details. LLNL-CODE-806117.
//
// This file is part of the MFEM library. For more information and source code
// availability visit https://mfem.org.
//
// MFEM is free software; you can redistribute it and/or modify it under the
// terms of the BSD-3 license. We welcome feedback and contributions, see file
// CONTRIBUTING.md for details.

/// Tests which make sure adding user-defined kernel specializations work.
/// These tests are compile/link-only tests

#include "mfem.hpp"
#include "unit_tests.hpp"

#include "fem/qinterp/eval_hdiv.hpp"

TEST_CASE("QInterp Eval HDiv Kernel Specializations", "[Specializations]")
{
   using namespace mfem;

   QuadratureInterpolator::TensorEvalHDivKernels::Specialization<
   2, QVectorLayout::byNODES, QuadratureInterpolator::PHYSICAL_VALUES, 2,
   4>::Add();
   QuadratureInterpolator::TensorEvalHDivKernels::Specialization<
   2, QVectorLayout::byNODES, QuadratureInterpolator::PHYSICAL_MAGNITUDES, 2,
   4>::Add();
}
